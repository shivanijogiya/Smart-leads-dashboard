import { z } from 'zod';

export const registerSchema = z.object({
  body: z.object({
    name: z.string().trim().min(2, 'Name must be at least 2 characters').max(80),
    email: z.string().trim().email('Enter a valid email').toLowerCase(),
    password: z.string().min(6, 'Password must be at least 6 characters'),
    role: z.enum(['admin', 'sales']).default('sales'),
  }),
});

export const loginSchema = z.object({
  body: z.object({
    email: z.string().trim().email('Enter a valid email').toLowerCase(),
    password: z.string().min(1, 'Password is required'),
  }),
});
